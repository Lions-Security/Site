import { motion } from 'motion/react';
import { Cloud, Terminal, Shield, Lock, Cpu, Globe } from 'lucide-react';

const tools = [
  { name: 'CLOUDFLARE', icon: Cloud, color: 'text-[#F38020]' },
  { name: 'RED HAT', icon: Cpu, color: 'text-[#EE0000]' },
  { name: 'CHECK POINT', icon: Shield, color: 'text-[#ED1C24]' },
  { name: 'SOPHOS', icon: Lock, color: 'text-[#0038A8]' },
  { name: 'KALI LINUX', icon: Terminal, color: 'text-[#557CF2]' },
  { name: 'BURP SUITE', icon: Globe, color: 'text-[#FF6633]' },
];

export default function StackTools() {
  return (
    <section id="stack" className="py-20 bg-surface border-y border-border overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="text-center">
          <p className="tech-label text-accent mb-4">Stack de Ferramentas & Soluções</p>
          <h2 className="text-2xl font-display font-bold text-light">Tecnologias que operamos diariamente</h2>
        </div>
      </div>
      
      {/* Infinite Marquee Slider */}
      <div className="relative flex overflow-hidden">
        <motion.div 
          className="flex whitespace-nowrap gap-16 items-center py-4"
          animate={{ x: [0, -1000] }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        >
          {[...tools, ...tools, ...tools].map((tool, i) => (
            <div key={`${tool.name}-${i}`} className="flex items-center gap-4 group opacity-40 hover:opacity-100 transition-opacity">
              <tool.icon size={32} className={`${tool.color}`} />
              <span className="text-4xl font-display font-black text-light tracking-tighter italic select-none">
                {tool.name}
              </span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
