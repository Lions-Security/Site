/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/layout/Navbar';
import Hero from './components/home/Hero';
import Services from './components/home/Services';
import About from './components/home/About';
import TrainingAcademy from './components/home/TrainingAcademy';
import Partners from './components/home/Partners';
import Footer from './components/layout/Footer';

export default function App() {
  return (
    <div className="flex bg-background text-text selection:bg-accent selection:text-white">
      {/* Sidebar Rail - Artistic Flair Theme */}
      <aside className="hidden lg:flex w-20 border-r border-border min-h-screen sticky top-0 flex-col items-center py-12 justify-between shrink-0">
        <div className="font-black text-2xl tracking-[0.2em] text-primary rotate-[-90deg] whitespace-nowrap mb-12">
          LION SECURITY
        </div>
        <nav className="flex flex-col gap-12">
          <div className="w-1.5 h-1.5 bg-accent" />
          <div className="w-1.5 h-1.5 bg-slate-300" />
          <div className="w-1.5 h-1.5 bg-slate-300" />
        </nav>
        <div className="text-[10px] text-muted font-mono tracking-[0.4em] rotate-[-90deg] uppercase whitespace-nowrap mt-12">
          ANGOLA.2026
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <Navbar />
        <main>
          <Hero />
          <Services />
          <About />
          <TrainingAcademy />
          <Partners />
        </main>
        <Footer />
      </div>
    </div>
  );
}
